package com.example.bluetoothchat

import android.Manifest
import android.app.Activity
import android.bluetooth.BluetoothAdapter
import android.bluetooth.BluetoothDevice
import android.bluetooth.BluetoothServerSocket
import android.bluetooth.BluetoothSocket
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.content.pm.PackageManager
import android.os.Build
import android.os.Bundle
import android.view.Gravity
import android.view.View
import android.widget.*
import java.io.BufferedReader
import java.io.InputStreamReader
import java.io.PrintWriter
import java.util.UUID
import java.util.concurrent.Executors

class MainActivity : Activity() {
    private val adapter: BluetoothAdapter? by lazy { BluetoothAdapter.getDefaultAdapter() }
    private val uuid: UUID = UUID.fromString("b1e7a100-8f2a-4c21-9d31-4a7f12c0aa11")
    private val io = Executors.newCachedThreadPool()
    private var socket: BluetoothSocket? = null
    private var writer: PrintWriter? = null
    private lateinit var status: TextView
    private lateinit var devicesBox: LinearLayout
    private lateinit var chatBox: LinearLayout
    private lateinit var messageInput: EditText
    private val found = linkedMapOf<String, BluetoothDevice>()

    private val receiver = object : BroadcastReceiver() {
        override fun onReceive(context: Context?, intent: Intent?) {
            if (intent?.action == BluetoothDevice.ACTION_FOUND) {
                val device = if (Build.VERSION.SDK_INT >= 33)
                    intent.getParcelableExtra(BluetoothDevice.EXTRA_DEVICE, BluetoothDevice::class.java)
                else @Suppress("DEPRECATION") intent.getParcelableExtra(BluetoothDevice.EXTRA_DEVICE)
                device?.let {
                    val label = try { "${it.name ?: "Неизвестное устройство"} (${it.address})" } catch (_: SecurityException) { it.address }
                    found[it.address] = it
                    runOnUiThread { addDeviceButton(label, it) }
                }
            } else if (intent?.action == BluetoothAdapter.ACTION_DISCOVERY_FINISHED) {
                runOnUiThread { status.text = "Поиск завершён · найдено: ${found.size}" }
            }
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        buildUi()
        requestBtPermissions()
        val filter = IntentFilter().apply {
            addAction(BluetoothDevice.ACTION_FOUND)
            addAction(BluetoothAdapter.ACTION_DISCOVERY_FINISHED)
        }
        registerReceiver(receiver, filter)
        startServer()
    }

    private fun buildUi() {
        val outer = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(22, 28, 22, 18)
            setBackgroundColor(0xFF100D19.toInt())
        }
        setContentView(outer)
        outer.addView(TextView(this).apply {
            text = "Bluetooth Chat"
            textSize = 27f; setTextColor(0xFFEDE7FF.toInt())
        })
        status = TextView(this).apply {
            text = "Проверка Bluetooth…"; textSize = 14f
            setTextColor(0xFFBDA9F5.toInt()); setPadding(0, 8, 0, 16)
        }
        outer.addView(status)
        val actions = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        actions.addView(actionButton("Найти устройства") { discover() }, LinearLayout.LayoutParams(0, -2, 1f))
        actions.addView(actionButton("Обновить") { showPaired() }, LinearLayout.LayoutParams(0, -2, 1f))
        outer.addView(actions)
        outer.addView(sectionTitle("Устройства"))
        val scrollDevices = ScrollView(this)
        devicesBox = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        scrollDevices.addView(devicesBox)
        outer.addView(scrollDevices, LinearLayout.LayoutParams(-1, 0, 1.0f))
        outer.addView(sectionTitle("Переписка"))
        val chatScroll = ScrollView(this)
        chatBox = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(4, 4, 4, 4) }
        chatScroll.addView(chatBox)
        outer.addView(chatScroll, LinearLayout.LayoutParams(-1, 0, 1.2f))
        val composer = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
        messageInput = EditText(this).apply {
            hint = "Сообщение…"; setTextColor(0xFFFFFFFF.toInt()); setHintTextColor(0xFF9B91A9.toInt())
            setSingleLine(true); setPadding(12, 4, 12, 4)
        }
        composer.addView(messageInput, LinearLayout.LayoutParams(0, 54, 1f))
        composer.addView(actionButton("Отправить") { sendMessage() })
        outer.addView(composer)
        showPaired()
    }

    private fun sectionTitle(s: String) = TextView(this).apply {
        text = s; textSize = 17f; setTextColor(0xFFE0D5FF.toInt()); setPadding(0, 15, 0, 8)
    }

    private fun actionButton(label: String, click: () -> Unit) = Button(this).apply {
        text = label; setOnClickListener { click() }
    }

    private fun requestBtPermissions() {
        if (Build.VERSION.SDK_INT >= 31) {
            val needed = arrayOf(Manifest.permission.BLUETOOTH_CONNECT, Manifest.permission.BLUETOOTH_SCAN)
                .filter { checkSelfPermission(it) != PackageManager.PERMISSION_GRANTED }
            if (needed.isNotEmpty()) requestPermissions(needed.toTypedArray(), 42)
            else enableBluetooth()
        } else enableBluetooth()
    }

    override fun onRequestPermissionsResult(requestCode: Int, permissions: Array<out String>, grantResults: IntArray) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        if (requestCode == 42 && grantResults.all { it == PackageManager.PERMISSION_GRANTED }) enableBluetooth()
        else status.text = "Нужны разрешения Bluetooth для поиска и подключения"
    }

    private fun enableBluetooth() {
        val a = adapter
        if (a == null) { status.text = "На этом телефоне нет Bluetooth"; return }
        try {
            if (!a.isEnabled) startActivity(Intent(BluetoothAdapter.ACTION_REQUEST_ENABLE))
            status.text = if (a.isEnabled) "Bluetooth включён · ожидание подключения" else "Включите Bluetooth"
        } catch (_: SecurityException) { status.text = "Нет разрешения Bluetooth" }
    }

    private fun showPaired() {
        devicesBox.removeAllViews()
        try {
            val paired = adapter?.bondedDevices ?: emptySet()
            paired.forEach { addDeviceButton("${it.name ?: "Устройство"} · ${it.address}", it) }
            if (paired.isEmpty()) devicesBox.addView(info("Нет сопряжённых устройств. Нажмите «Найти устройства»."))
        } catch (_: SecurityException) { devicesBox.addView(info("Разрешите доступ к Bluetooth.")) }
    }

    private fun discover() {
        val a = adapter ?: return
        try {
            if (!a.isEnabled) { enableBluetooth(); return }
            found.clear(); devicesBox.removeAllViews()
            status.text = "Идёт поиск…"
            if (a.isDiscovering) a.cancelDiscovery()
            a.startDiscovery()
        } catch (_: SecurityException) { status.text = "Нет разрешения на поиск устройств" }
    }

    private fun addDeviceButton(label: String, device: BluetoothDevice) {
        val button = Button(this).apply {
            text = label
            setOnClickListener { connect(device) }
        }
        devicesBox.addView(button)
    }

    private fun connect(device: BluetoothDevice) {
        status.text = "Подключение к устройству…"
        io.execute {
            try {
                adapter?.cancelDiscovery()
                val s = device.createRfcommSocketToServiceRecord(uuid)
                s.connect()
                onConnected(s)
            } catch (e: Exception) {
                runOnUiThread { status.text = "Не удалось подключиться: ${e.localizedMessage ?: "ошибка"}" }
            }
        }
    }

    private fun startServer() {
        io.execute {
            try {
                val server: BluetoothServerSocket? = adapter?.listenUsingRfcommWithServiceRecord("Bluetooth Chat", uuid)
                val accepted = server?.accept()
                server?.close()
                if (accepted != null) onConnected(accepted)
            } catch (_: Exception) { }
        }
    }

    @Synchronized private fun onConnected(s: BluetoothSocket) {
        socket?.close()
        socket = s
        writer = PrintWriter(s.outputStream, true)
        runOnUiThread { status.text = "Подключено: ${try { s.remoteDevice.name ?: s.remoteDevice.address } catch (_: Exception) { "устройство" }}" }
        io.execute {
            try {
                val reader = BufferedReader(InputStreamReader(s.inputStream, Charsets.UTF_8))
                while (true) {
                    val line = reader.readLine() ?: break
                    runOnUiThread { addChatLine("Собеседник", line) }
                }
            } catch (_: Exception) {
                runOnUiThread { status.text = "Соединение завершено" }
            }
        }
    }

    private fun sendMessage() {
        val text = messageInput.text.toString().trim()
        if (text.isEmpty()) return
        val out = writer
        if (out == null) { status.text = "Сначала подключитесь к устройству"; return }
        io.execute {
            out.println(text)
            runOnUiThread {
                addChatLine("Вы", text)
                messageInput.text.clear()
            }
        }
    }

    private fun addChatLine(sender: String, message: String) {
        chatBox.addView(TextView(this).apply {
            text = "$sender: $message"
            textSize = 15f
            setTextColor(if (sender == "Вы") 0xFFBDA9F5.toInt() else 0xFFEDE7FF.toInt())
            setPadding(8, 7, 8, 7)
        })
    }

    private fun info(s: String) = TextView(this).apply {
        text = s; setTextColor(0xFFBDB4C8.toInt()); setPadding(8, 12, 8, 12)
    }

    override fun onDestroy() {
        try { unregisterReceiver(receiver) } catch (_: Exception) {}
        try { socket?.close() } catch (_: Exception) {}
        io.shutdownNow()
        super.onDestroy()
    }
}
